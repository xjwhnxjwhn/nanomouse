# 五筆畫

配方： ℞ **stroke**

[Rime](https://rime.im) 五筆畫輸入方案

## 用法

`h,s,p,n,z` 代表橫、豎、撇、捺、折

## 安裝

[東風破](https://github.com/rime/plum) 安裝口令： `bash rime-install stroke`

授權條款：見 [LICENSE](LICENSE)
