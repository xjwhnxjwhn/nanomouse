# NanoMouse FUTO Swipe assets

This package contains unmodified FUTO Swipe model weights from
https://huggingface.co/futo-org/futo-swipe and trie inputs generated for
NanoMouse.

- `honorable_sturgeon`: universal gesture encoder.
- `magic_macaw`: English QWERTY decoder.
- `hungry_jellyfish`: English context language model and vocabulary.
- `english_frequency.txt`: English trie input derived from the frequency list
  already used by NanoMouse.
- `pinyin_frequency.txt`: pinyin trie input derived from NanoMouse's compact
  rime-ice/libime lexicon. It contains pinyin only; Rime or libime generates
  Hanzi candidates.

The weights are subject to `FUTO-MODEL-WEIGHTS-LICENSE.md`. The decoder source
is subject to GPL-3.0 as included in `FUTO-SWIPE-LIBRARY-LICENSE.txt` and in the
NanoMouse source repository.

Powered by FUTO Swipe technology.
