# Rime-Hannom

Rime Hán Nôm Input Schema 部𢫈漢喃 Bộ gõ Hán Nôm

(derived from HannomPS)

Current maintainers:

- 以成 (Dĩ Thành) <huang-junxin@qq.com>

Authors of HannomPS:

- Keepout2010 <Keepout2010@163.com>

- 学习之云 <hitsuji@pku.edu.cn>
